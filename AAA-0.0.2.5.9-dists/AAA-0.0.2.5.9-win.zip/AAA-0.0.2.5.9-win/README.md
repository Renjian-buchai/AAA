# AAA
By Stressed with Ale
ver. 0.0.2.5.9 <br> <br> 
Credits: <br>
  Programming: <br> 
  Gahjouyooj <br> 
    Github https://github.com/Renjian-buchai <br> 
    Discord 鸭励善达#1642 
  Character Art: <br>
  The Alexer <br>
    Discord The Alexer#3370 <br>
  Background Art: <br>
  Gahjouyooj <br>
    Github https://github.com/Renjian-buchai <br>
    Discord 鸭励善达#1642 <br>
  BG Music: <br>
  Sharou <br>
    Twitter https://twitter.com/shlllllw <br>
    Youtube https://www.youtube.com/@Sharou <br>
    dova-s.jp https://dova-s.jp/_contents/author/profile106.html <br>
